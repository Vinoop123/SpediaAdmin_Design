// To add ripple effect

$(".btn").addClass("waves-effect waves-light");
$(".nav-item a").addClass("waves-effect waves-dark");
$("input [type='checkbox']").addClass("waves-effect waves-light");